console.log("hello world");
var a=1; //var es una palabra reservada pra definir variables
var b=2;
var r=a+b;
console.log("resultado:"+r);
var n1=4;
var n2=5;
var m=n1*n2;

console.log("resultado:"+m);
var ra=Math. sqrt(1422);
var mo=Math. trunc(ra);
console.log("resultado decimal:"+ra);
console.log("resultado:"+mo);

