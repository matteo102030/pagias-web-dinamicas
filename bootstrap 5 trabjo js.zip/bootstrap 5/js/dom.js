console.log("entramos");

var items = document.getElementsByClassName("item");

var cantidad = items.length;  // - 3

console.log(cantidad);

var div =document.createElement("div");
div;
div.innerText = "aprendiendo JavaSript";
var divUno=document.getElementById("uno");
divUno.appendChild(div);


var lista=document.getElementById("lista");

var hijo =document.createElement("li");
hijo.innerText = "item 4 (li nuevo)";
lista.appendChild(hijo);

document.getElementById('tres').style.color = 'red';
document.getElementById('lista').style.color = 'green';

var cuerpo=document.getElementById("body");
var hola =document.createElement("div");
cuerpo.appendChild(hola);
var texto =document.createElement("p");
texto.innerText = "hola,como esta toda la familia,  bueno gracias hjjfjfduhdhdyudhfhfhf";
hola.appendChild(texto);

var list =document.createElement("ul");
hola.appendChild(list);
var itrem =document.createElement("li");
itrem.innerText = "item 5";
list.appendChild(itrem);

